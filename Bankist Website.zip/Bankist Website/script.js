'use strict';

///////////////////////////////////////
// Modal window

const modal = document.querySelector('.modal');
const overlay = document.querySelector('.overlay');
const btnCloseModal = document.querySelector('.btn--close-modal');
const btnsOpenModal = document.querySelectorAll('.btn--show-modal');

const tabs = document.querySelectorAll('.operations__tab');
const tabContents = document.querySelectorAll('.operations__content');
const navLink = document.querySelectorAll('.nav__link');
const section = document.querySelectorAll('.section');
const slide = document.querySelectorAll('.slide');
const slider = document.querySelector('.slider');
const lazyImg = document.querySelectorAll('img[data-src]');
const tabsContainer = document.querySelector('.operations__tab-container');
const navLinks = document.querySelector('.nav__links');
const nav = document.querySelector('.nav');
const navLogo = document.querySelector('.nav__logo');
const btnScroll = document.querySelector('.btn--scroll-to');
const sec1 = document.querySelector('#section--1');
const header = document.querySelector('.header');
const btnLeft = document.querySelector('.slider__btn--left');
const btnRight = document.querySelector('.slider__btn--right');
const dotsContainer = document.querySelector('.dots');

const openModal = function () {
  modal.classList.remove('hidden');
  overlay.classList.remove('hidden');
};

const closeModal = function () {
  modal.classList.add('hidden');
  overlay.classList.add('hidden');
};

for (let i = 0; i < btnsOpenModal.length; i++)
  btnsOpenModal[i].addEventListener('click', openModal);

btnCloseModal.addEventListener('click', closeModal);
overlay.addEventListener('click', closeModal);

document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
    closeModal();
  }
});


btnScroll.addEventListener('click', function(){
  sec1.scrollIntoView({behavior: 'smooth'});
});

navLinks.addEventListener('click', function(e){
  e.preventDefault();
  const clicked = e.target;
  document.querySelector(clicked.getAttribute('href')).scrollIntoView({behavior: 'smooth'});
});

tabsContainer.addEventListener('click', function(e){
  const clicked =  e.target.closest('.operations__tab');
  if(clicked?.classList.contains('operations__tab')){
    
    tabs.forEach(t => t.classList.remove('operations__tab--active'));
    tabContents.forEach(t => t.classList.remove('operations__content--active'));
    clicked.classList.add('operations__tab--active');
    document.querySelector(`.operations__content--${clicked.dataset.tab}`).classList.add('operations__content--active');    
  }
});

function hoverHandler(e){
  if(e.target.classList.contains('nav__link')){
    const hovered = e.target;
  navLink.forEach(element => {
if(hovered !== element){
  element.style.opacity = this;
}
  });
navLogo.style.opacity = this;
}
}

nav.addEventListener('mouseover', hoverHandler.bind(0.5));

nav.addEventListener('mouseout', hoverHandler.bind(1));

const obsCallback = function(entries){
  entries.forEach(el => {
    if(!el.isIntersecting){
      nav.classList.add('sticky');
    }else{
      nav.classList.remove('sticky');
    }
  });
}
const obsOps = {
  root: null,
  threshold: 0,
  rootMargin: '-90px',
}
const obs = new IntersectionObserver(obsCallback, obsOps);
obs.observe(header);

const secObserver = new IntersectionObserver(entries => {
  entries.forEach(curr => {
    curr.target.classList.add('section--hidden');
    if (curr.isIntersecting) {
      curr.target.classList.remove('section--hidden');
      // secObserver.unobserve(curr.target)
    }
    
    else{
      curr.target.classList.add('section--hidden');

    }
  }
  )
}, {
  root: null,
  threshold: 0.2,
});

section.forEach(curr => secObserver.observe(curr));
function lazyLoad(entries){
  entries.forEach(img => {
    if(img.isIntersecting){
      img.target.src = img.target.dataset.src;
      img.target.addEventListener('load', () => img.target.classList.remove('lazy-img'));
    }
  });
}
const imgObserver = new IntersectionObserver(lazyLoad, {
  root: null,
  threshold: 0,
  rootMargin: '-100px'
});
lazyImg.forEach(img => imgObserver.observe(img));

///////////  SLIDE /////////// 
let currSlide = 0;
slide.forEach((slide, i) => slide.style.transform = `translateX(${100 * i}%)`);


function prevSlide(){
  // activateDot();
  currSlide === 0 ? currSlide = slide.length - 1 : currSlide--;
  slide.forEach((slide, i) => slide.style.transform = `translateX(${100 * (i - currSlide)}%)`);
}
function nextSlide(){
  currSlide === slide.length - 1 ? currSlide = 0 : currSlide++;
  slide.forEach((slide, i) => slide.style.transform = `translateX(${100 * (i - currSlide)}%)`);
  // activateDot();
}
const activateDot = function(){
  document.querySelectorAll('.dots__dot').forEach((dots) => { 
    dots.classList.remove('dots__dot--active'); 
    // dot.classList.add('dots__dot--active');
    });
    currSlide === slide.length - 1 ? currSlide = 0 : currSlide++;
    document.querySelector(`.dots__dot[data-slide=${currSlide}]`).classList.add('dots_dot--active');
}
// activateDot()
btnRight.addEventListener('click', function(){
  nextSlide();
});

btnLeft.addEventListener('click', function(){
  prevSlide();
});

document.addEventListener('keydown', function(e){ 
    if(e.key === 'ArrowRight'){
      nextSlide();
    }else if (e.key === 'ArrowLeft'){
      prevSlide();
    }
    
});

slide.forEach((_, i) => 
  dotsContainer.insertAdjacentHTML('beforeend', `<button class="dots__dot" data-slide="${i}"></button>`),
);
document.querySelector('.dots__dot[data-slide]').classList.add('dots__dot--active');

dotsContainer.addEventListener('click', (e) => {
  const dot = e.target;
  if (dot.classList.contains('dots__dot')) {
    slide.forEach((s, i) => s.style.transform = `translateX(${100 * (i - dot.dataset.slide)}%)`);
    //  activateDot();
  }
});
